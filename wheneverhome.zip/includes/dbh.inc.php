<?php

$servername = "mysql";
$dBUsername = "u464426980_dylddean";
$dBPassword = "Wolfman7005$";
$dBName = "u464426980_phpproject1";

$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
	die("Connection failed: ".mysqli_connect_error());
}
